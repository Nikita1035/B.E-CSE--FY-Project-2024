CREATE DATABASE  IF NOT EXISTS `crop_disease_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `crop_disease_db`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: crop_disease_db
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cropdiseases`
--

DROP TABLE IF EXISTS `cropdiseases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cropdiseases` (
  `diseId` bigint NOT NULL,
  `diseaseName` varchar(500) DEFAULT NULL,
  `details` varchar(500) DEFAULT NULL,
  `cropName` varchar(200) DEFAULT NULL,
  `userid` varchar(200) DEFAULT NULL,
  `cropPart` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`diseId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cropdiseases`
--

LOCK TABLES `cropdiseases` WRITE;
/*!40000 ALTER TABLE `cropdiseases` DISABLE KEYS */;
INSERT INTO `cropdiseases` VALUES (1001,'Apple_scab','Leaves infected with the apple scab fungus usually fall from trees in autumn or early winter. The fungus continues to live within the leaves during winter, forming small, flask-shaped bodies, in which spores (ascospores) develop. These ascospores mature in spring and are forcibly ejected during spring rains','Apple','admin','Leaf'),(1002,'Black_rot','Black rot is caused by a bacteria, Xanthomonas campestris pv. campestris, that can infect most crucifer crops at any growth stage. This disease is difficult for growers to manage and is considered the most serious disease of crucifer crops worldwide ','Apple','admin','Leaf'),(1003,'Apple Cedar apple rust','Cedar-apple rust fruit spots usually appear near the blossom end (calyx) of fruit (Figure 4). They are similar in color to leaf spots (yellow- orange), but are much larger (� inch or more in diameter). Each fruit spot is surrounded by a dark green zone on otherwise light green fruit.','Apple','admin','Leaf'),(1004,'Black Spot','Citrus black spot is a fungal disease marked by dark necrotic spots or blotches on the rinds of fruit. It produces early fruit drop, reduces crop yields and, if not controlled, renders the highly blemished fruit unmarketable.','Orange','admin','Leaf'),(1005,'canker','Citrus canker is a disease affecting Citrus species caused by the bacterium Xanthomonas (X. axonopodis; X. campestris). Infection causes lesions on the leaves, stems, and fruit of citrus trees, including lime, oranges, and grapefruit.','Orange','admin','Leaf'),(1006,'Fresh Apples','Fresh Apples','Apple','admin','Fruit'),(1007,'Bitter Rot','Bitter Rot apple disease','Apple','admin','Fruit'),(1008,'Fresh Apple Leaves','Fresh Apple leaves','Apple','admin','Leaf'),(1009,'Apple Fruit scab','Apple Fruit Scab','Apple','admin','Fruit');
/*!40000 ALTER TABLE `cropdiseases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cropdiseasesimages`
--

DROP TABLE IF EXISTS `cropdiseasesimages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cropdiseasesimages` (
  `imgId` bigint NOT NULL,
  `diseaseName` varchar(500) DEFAULT NULL,
  `imgPath` varchar(500) DEFAULT NULL,
  `cropName` varchar(200) DEFAULT NULL,
  `userid` varchar(200) DEFAULT NULL,
  `cropPart` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`imgId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cropdiseasesimages`
--

LOCK TABLES `cropdiseasesimages` WRITE;
/*!40000 ALTER TABLE `cropdiseasesimages` DISABLE KEYS */;
/*!40000 ALTER TABLE `cropdiseasesimages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cropdiseasesimagesfarmer`
--

DROP TABLE IF EXISTS `cropdiseasesimagesfarmer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cropdiseasesimagesfarmer` (
  `imgId` bigint NOT NULL,
  `diseaseName` varchar(500) DEFAULT NULL,
  `imgPath` varchar(500) DEFAULT NULL,
  `cropName` varchar(200) DEFAULT NULL,
  `userid` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`imgId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cropdiseasesimagesfarmer`
--

LOCK TABLES `cropdiseasesimagesfarmer` WRITE;
/*!40000 ALTER TABLE `cropdiseasesimagesfarmer` DISABLE KEYS */;
/*!40000 ALTER TABLE `cropdiseasesimagesfarmer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crops`
--

DROP TABLE IF EXISTS `crops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crops` (
  `cropId` bigint NOT NULL,
  `name` varchar(500) DEFAULT NULL,
  `details` varchar(500) DEFAULT NULL,
  `userid` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`cropId`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crops`
--

LOCK TABLES `crops` WRITE;
/*!40000 ALTER TABLE `crops` DISABLE KEYS */;
INSERT INTO `crops` VALUES (1001,'Apple','asdfasdf','test22'),(1002,'Rose','testdsdfd','jayesh'),(1003,'Corn','Corn','test22'),(1004,'Potato','fdsfsdfdsf','test22'),(1005,'Peach','The peach is a deciduous tree native to the region of Northwest China between the Tarim Basin and the north slopes of the Kunlun Mountains, where it was first domesticated and cultivated. It bears edible juicy fruits with various characteristics, most called peaches and others, nectarines','test22'),(1006,'Pepper','Black pepper is a flowering vine in the family Piperaceae, cultivated for its fruit, known as a peppercorn, which is usually dried and used as a spice and seasoning. When fresh and fully mature, the fruit is about 5 mm in diameter, dark red, and contains a single seed, like all drupes','test22'),(1007,'Orange','The orange is the fruit of various citrus species in the family Rutaceae; it primarily refers to Citrus � sinensis, which is also called sweet orange, to distinguish it from the related Citrus � aurantium, referred to as bitter orange','test22'),(1008,'Grape','A grape is a fruit, botanically a berry, of the deciduous woody vines of the flowering plant genus Vitis. Grapes can be eaten fresh as table grapes or they can be used for making wine, jam, grape juice, jelly, grape seed extract, raisins, vinegar, and grape seed oil.','test22'),(1009,'Cherry','A cherry is the fruit of many plants of the genus Prunus, and is a fleshy drupe. Commercial cherries are obtained from cultivars of several species, such as the sweet Prunus avium and the sour Prunus cerasus','test22'),(1010,'Strawberry','The garden strawberry is a widely grown hybrid species of the genus Fragaria, collectively known as the strawberries, which are cultivated worldwide for their fruit. The fruit is widely appreciated for its characteristic aroma, bright red color, juicy texture, and sweetness','test22'),(1011,'Squash','Cucurbita is a genus of herbaceous vines in the gourd family, Cucurbitaceae native to the Andes and Mesoamerica. Five species are grown worldwide for their edible fruit, variously known as squash, pumpkin, or gourd, depending on species, variety, and local parlance, and for their seeds','test22'),(1012,'sss','dfs','admin');
/*!40000 ALTER TABLE `crops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expertsuggestion`
--

DROP TABLE IF EXISTS `expertsuggestion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expertsuggestion` (
  `dId` int NOT NULL,
  `userid` varchar(200) DEFAULT NULL,
  `typ` varchar(200) DEFAULT NULL,
  `title` varchar(9000) DEFAULT NULL,
  `details` longblob,
  `reflink` varchar(200) DEFAULT NULL,
  `soiltype` varchar(200) DEFAULT NULL,
  `weatherTxt` varchar(200) DEFAULT NULL,
  `plantName` varchar(200) DEFAULT NULL,
  `diseaseName` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`dId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expertsuggestion`
--

LOCK TABLES `expertsuggestion` WRITE;
/*!40000 ALTER TABLE `expertsuggestion` DISABLE KEYS */;
INSERT INTO `expertsuggestion` VALUES (1001,'admin','NA','asdf',_binary 'adsf','adfs','Sandy soil','<--select-->','Apple','Apple_scab'),(1002,'admin','NA','Preventive measures to handle apple scab disease',_binary 'The apple scab fungus needs moisture on the leaves to start a new infection. A well pruned tree with an open canopy allows air to move through the tree and dry the leaves quickly. This can help reduce the severity of apple scab in a tree.','https://extension.umn.edu/plant-diseases/apple-scab#:~:text=The%20apple%20scab%20fungus%20needs,apple%20scab%20in%20a%20tree.','Sandy soil','Haze','Apple','Apple_scab');
/*!40000 ALTER TABLE `expertsuggestion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `labels`
--

DROP TABLE IF EXISTS `labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `labels` (
  `srNo` int NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `disease` varchar(200) DEFAULT NULL,
  `cropPart` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `labels`
--

LOCK TABLES `labels` WRITE;
/*!40000 ALTER TABLE `labels` DISABLE KEYS */;
INSERT INTO `labels` VALUES (0,'Apple','Apple_scab','Leaf'),(1,'Apple','Black_rot','Leaf'),(2,'Apple','Apple Cedar apple rust','Leaf'),(0,'Orange','Black Spot','Leaf'),(1,'Orange','canker','Leaf'),(0,'Apple','Fresh Apples','Fruit'),(1,'Apple','Bitter Rot','Fruit'),(3,'Apple','Fresh Apple Leaves','Leaf'),(2,'Apple','Apple Fruit scab','Fruit');
/*!40000 ALTER TABLE `labels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `userid` varchar(200) NOT NULL,
  `username` varchar(200) DEFAULT NULL,
  `pass` varchar(200) DEFAULT NULL,
  `loginsts` varchar(200) DEFAULT NULL,
  `utype` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('admin','administrator','admin@123','active','admin','na');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weathertext`
--

DROP TABLE IF EXISTS `weathertext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `weathertext` (
  `weatherTxt` varchar(200) NOT NULL,
  PRIMARY KEY (`weatherTxt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weathertext`
--

LOCK TABLES `weathertext` WRITE;
/*!40000 ALTER TABLE `weathertext` DISABLE KEYS */;
INSERT INTO `weathertext` VALUES ('Blizzard'),('Blowing snow'),('Cloudy skies'),('Fog'),('Freezing drizzle'),('Freezing fog'),('Haze'),('Heavy freezing drizzle'),('Heavy rain'),('Heavy rain at times'),('Heavy snow'),('Ice pellets'),('Light drizzle'),('Light freezing rain'),('Light rain'),('Light rain shower'),('Light showers of ice pellets'),('Light sleet'),('Light sleet showers'),('Light snow'),('Light snow showers'),('Mist'),('Moderate or heavy freezing rain'),('Moderate or heavy rain shower'),('Moderate or heavy rain with thunder'),('Moderate or heavy showers of ice pellets'),('Moderate or heavy sleet'),('Moderate or heavy sleet showers'),('Moderate or heavy snow showers'),('Moderate or heavy snow with thunder'),('Moderate rain'),('Moderate rain at times'),('Moderate snow'),('Overcast skies'),('Partly Cloudy skies'),('Patchy freezing drizzle possible'),('Patchy heavy snow'),('Patchy light drizzle'),('Patchy light rain'),('Patchy light rain with thunder'),('Patchy light snow'),('Patchy light snow with thunder'),('Patchy moderate snow'),('Patchy rain possible'),('Patchy sleet possible'),('Patchy snow possible'),('Sunny skies'),('Thundery outbreaks possible'),('Torrential rain shower');
/*!40000 ALTER TABLE `weathertext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'crop_disease_db'
--

--
-- Dumping routines for database 'crop_disease_db'
--
/*!50003 DROP PROCEDURE IF EXISTS `changePassword` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `changePassword`(in userid1 varchar(200),in pass1 varchar(200))
BEGIN
update users set pass=pass1 where userid=userid1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `chkPass` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `chkPass`(in userid1 varchar(200),in pass1 varchar(200))
BEGIN
select * from users where userid=userid1 and pass=pass1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getMaxIdPlantImg` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getMaxIdPlantImg`()
BEGIN
select ifnull(max(imgId),1000) as mxid from cropDiseasesImages;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getMaxIdPlantImgFarmer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getMaxIdPlantImgFarmer`()
BEGIN
select ifnull(max(imgId),1000) as mxid from cropDiseasesImagesFarmer;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getPlantDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getPlantDetails`(in plant1 varchar(200),in disease1 varchar(200),in typ1 varchar(200))
BEGIN
select * from expertSuggestion where typ=typ1 and cropName=plant1 and diseaseName=disease1 ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getPlantDetails1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getPlantDetails1`(in plant1 varchar(200),in disease1 varchar(200),in soiltyp1 varchar(200))
BEGIN
select * from expertSuggestion where soiltype=soiltyp1 and cropName=plant1 and diseaseName=disease1 ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getPlantDiseaseImg` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getPlantDiseaseImg`(in plant varchar(200),in disease varchar(200))
BEGIN
select * from cropdiseasesimages where cropName=plant and diseaseName=disease;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getPlantDiseases` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getPlantDiseases`(in plant varchar(200))
BEGIN
select * from cropDiseases where cropName=plant;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getPlants` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getPlants`()
BEGIN
select * from crops;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insertExpertSuggestions` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertExpertSuggestions`(in userid1 varchar(200),in typ1 varchar(200),title1 varchar(9000)
,in plantName1 varchar(200), in diseName1 varchar(500), in details1 longblob,reflink1 varchar(200),soiltyp varchar(200),wtxt varchar(200))
begin
declare mxid integer;
set mxid=(select ifnull(max(dId),1000) from expertSuggestion);
set mxid=mxid+1;
insert into expertSuggestion values(mxid,userid1,typ1,title1,details1,reflink1,soiltyp,wtxt,plantName1,diseName1);
 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insertPlant` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertPlant`(in userid1 varchar(200),in name1 varchar(500), in details1 varchar(500))
begin
declare mxid integer;
set mxid=(select ifnull(max(cropId),1000) from crops);
set mxid=mxid+1;
insert into crops values(mxid,name1,details1,userid1);
 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insertPlantDiseases` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertPlantDiseases`(in userid1 varchar(200),in diseName1 varchar(500), in details1 varchar(500),plantName1 varchar(200),cropPart1 varchar(200))
begin
declare mxid integer;
set mxid=(select ifnull(max(diseId),1000) from cropDiseases);
set mxid=mxid+1;
insert into cropDiseases values(mxid,diseName1,details1,plantName1,userid1,cropPart1);
set mxid=(select ifnull(max(srNo),-1)+1 as mxid  from labels where title=plantName1   and cropPart=cropPart1); 
if not exists(select *  from labels where title=plantName1 and disease=diseName1 and cropPart=cropPart1) then
insert into labels values(mxid,plantName1, diseName1, cropPart1);
end if;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insertPlantDiseasesImages` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertPlantDiseasesImages`(in userid1 varchar(200),in diseName1 varchar(500), in imgPath1 varchar(500),plantName1 varchar(200),cate varchar(200))
begin
declare mxid integer;
set mxid=(select ifnull(max(imgId),1000) from cropDiseasesImages);
set mxid=mxid+1;
insert into cropDiseases values(mxid,diseName1,imgPath1,plantName1,userid1,cate);
 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updatePassword` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updatePassword`(in userid1 varchar(200),in pass1 varchar(200))
BEGIN
update users set pass=pass1 where userid=userid1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `useridAuth` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `useridAuth`(in userid1 varchar(200))
BEGIN
select * from users where userid=userid1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `userlogin` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `userlogin`(in userid1 varchar(200),in pass1 varchar(200))
begin
select * from users where userid=userid1 and pass=pass1 and loginsts='active';
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-11 17:57:57
