package com.crop.disease.detection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CropDiseaseDetectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
