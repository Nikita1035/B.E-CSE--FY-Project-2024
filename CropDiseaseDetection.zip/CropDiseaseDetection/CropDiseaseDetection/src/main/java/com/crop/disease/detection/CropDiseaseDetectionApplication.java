package com.crop.disease.detection;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CropDiseaseDetectionApplication {

	public static void main(String[] args) {
		SpringApplication.run(CropDiseaseDetectionApplication.class, args);
	}

}
