package com.crop.disease.detection;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.models.Login;
import com.models.Pass;
import com.models.CropDetails;
import com.models.CropDisease;
import com.models.CropDiseaseImg;
import com.models.CropDiseaseImgFarmer;
import com.models.Crops;
import com.models.UserReg;
import com.services.JavaFuns;
import com.services.Mail;
import com.services.RandomString;

@Controller
public class CropController implements ErrorController{
	@RequestMapping("/home")
	public ModelAndView index()
	{
		ModelAndView mv=new ModelAndView();
		mv.setViewName("index.jsp");
		Crops plant=new Crops();
		plant.getPlants();
		List<Crops> lstplant=plant.getLstplants();
		mv.addObject("lst",lstplant);
		return mv;
	 
	}
	@RequestMapping("/FromPythonPred")
	public String FromPythonPred(HttpServletRequest request)
	{
		if(request.getParameter("cate").trim().equals("-1"))
		{
			return "Success.jsp?type=nocategory";	
		}
		else
		return "prediction.jsp?type="+request.getParameter("cate").trim()+"&img="+request.getParameter("img").trim()+"&img1="+request.getParameter("img1").trim();
	}
	 @RequestMapping("/error")
	    public String handleError() {
	        //do something like logging
			return "home";
	    }
	  
	    public String getErrorPath() {
	        return "/error";
	    }
	    @RequestMapping("/RegDSImg")
		public String RegDSImg()
		{
			return "RegDSImg.jsp";
		}
		@RequestMapping("/RegCrops")
		public String RegCrops()
		{
			return "RegCrops.jsp";
		}
		@RequestMapping("/forgot")
		public String forgot()
		{
			return "Forgot.jsp";
		}
		@RequestMapping("/ChangePass")
		public String ChangePass()
		{
			return "ChangePass.jsp";
		}
		@RequestMapping("/passRecoveryOTPAuth")
		public ModelAndView passRecoveryOTPAuth(UserReg user)
		{
			ModelAndView mv=new ModelAndView();
			try {
				if(user.getSentOTP().equals(user.getOtp()))
				{
					String pass=RandomString.getAlphaNumericString(8);
					user.setPass(pass);
					if(user.updatePass())
					{
						
					}
					
					
				    mv.setViewName("Success.jsp?type=passEmail");
				    
				    Mail mail=new Mail();
				    String msg="Dear "+user.getName()+" \n Your password has been reset to "+pass;
				    System.out.println("pass="+pass);
				    try
				    {
				    	if(mail.sendMail(msg,user.getEmail(), "New password"))
				    	{
				    		
				    	}
				    }
				    catch (Exception e) {
						// TODO: handle exception
					}
				}
				else
				{
					mv.setViewName("Failure.jsp?type=passEmail");
				}
				
			}
			catch (Exception e) {
				// TODO: handle exception
			}
			
		    return mv;
		}
		@RequestMapping("/passRecovery")
		public ModelAndView passRecovery(UserReg user)
		{
			ModelAndView mv=new ModelAndView();
			try {
				if(user.useridAuth())
				{
					String otp=RandomString.getAlphaNumericString(4);
					
				    mv.setViewName("ForgotOTP.jsp");
				    mv.addObject("userid",user.getUserid());
				    mv.addObject("otp",otp);
				    mv.addObject("email",user.getEmail());
				    Mail mail=new Mail();
				    String msg="Dear "+user.getName()+" \n Your one time password is "+otp;
				    System.out.println("otp="+otp);
				    try
				    {
				    	if(mail.sendMail(msg,user.getEmail(), "One Time Password"))
				    	{
				    		
				    	}
				    }
				    catch (Exception e) {
						// TODO: handle exception
					}
				}
				else
				{
					mv.setViewName("Failure.jsp?type=Auth");
				}
				
			}
			catch (Exception e) {
				// TODO: handle exception
			}
			
		    return mv;
		}
		 
		@RequestMapping("/ChangePassService")
		public String ChangePassService(Pass eobj,HttpSession ses)
		{ 
			 try
			 { 
				 eobj.setUserid(ses.getAttribute("userid").toString().trim());
				 if(eobj.changePassword())
				 { 
					 return "Success.jsp?type=ChangePass";
				 }
				 else
				 { 
					 return "Failure.jsp?type=ChangePass";
				 }
			 }
			 catch (Exception e) {
				// TODO: handle exception
				 System.out.println("err="+e.getMessage());
				 return("Failure.jsp?type=Auth");
			}
			 
		}
		@RequestMapping("/RegCropDiseaseImgFarmerAcc")
		public ModelAndView RegCropDiseaseImgFarmerAcc()
		{
			ModelAndView mv=new ModelAndView();
			mv.setViewName("UploadPlantImgFarmerAcc.jsp");
			Crops plants=new Crops();
			CropDiseaseImgFarmer img=new CropDiseaseImgFarmer();
			img.generateImgId();
			
			plants.getPlants();
			List<Crops> lst=plants.getLstplants();
			mv.addObject("id",img.getImgId());
			mv.addObject("lst",lst);
			return mv;
		}
		@RequestMapping("/RegCropDiseaseImgFarmer")
		public ModelAndView RegCropDiseaseImgFarmer()
		{
			ModelAndView mv=new ModelAndView();
			mv.setViewName("UploadPlantImgFarmer.jsp");
			Crops plants=new Crops();
			CropDiseaseImgFarmer img=new CropDiseaseImgFarmer();
			img.generateImgId();
			
			plants.getPlants();
			List<Crops> lst=plants.getLstplants();
			mv.addObject("id",img.getImgId());
			mv.addObject("lst",lst);
			return mv;
		}
		@RequestMapping("/RegCropDiseaseImg")
		public ModelAndView RegCropDiseaseImg()
		{
			ModelAndView mv=new ModelAndView();
			mv.setViewName("UploadCropImg.jsp");
			Crops plants=new Crops();
			CropDiseaseImg img=new CropDiseaseImg();
			img.generateImgId();
			
			plants.getPlants();
			List<Crops> lst=plants.getLstplants();
			mv.addObject("id",img.getImgId());
			mv.addObject("lst",lst);
			return mv;
		}
		@RequestMapping("/RegCropDisease")
		public ModelAndView RegCropsDisease()
		{
			ModelAndView mv=new ModelAndView();
			mv.setViewName("RegCropsDisease.jsp");
			Crops plants=new Crops();
			plants.getPlants();
			List<Crops> lst=plants.getLstplants();
			mv.addObject("lst",lst);
			return mv;
		}
		@RequestMapping("/Diseases")
		public ModelAndView Diseases(HttpServletRequest request)
		{
			
			ModelAndView mv=new ModelAndView();
			
			mv.setViewName("Diseases.jsp");
			CropDisease plants=new CropDisease();
			try {
			plants.setPlantName(request.getParameter("plantName").toString().trim());
			plants.getPlantDiseases();
			System.out.println("plant Name="+request.getParameter("plantName").toString().trim());
			List<CropDisease> lst=plants.getLstplants();
			mv.addObject("lst",lst);
			System.out.println("plant Name="+lst.size()+" "+lst.get(0).getName());
			}
			catch (Exception e) {
				// TODO: handle exception
			}
			return mv;
		}
		@RequestMapping("/Diseases1")
		public ModelAndView Diseases1(HttpServletRequest request)
		{
			
			ModelAndView mv=new ModelAndView();
			
			mv.setViewName("Diseases2.jsp");
			CropDisease plants=new CropDisease();
			try {
			plants.setPlantName(request.getParameter("plantName").toString().trim());
			plants.getPlantDiseases();
			System.out.println("plant Name="+request.getParameter("plantName").toString().trim());
			List<CropDisease> lst=plants.getLstplants();
			mv.addObject("lst",lst);
			System.out.println("plant Name="+lst.size()+" "+lst.get(0).getName());
			}
			catch (Exception e) {
				// TODO: handle exception
			}
			return mv;
		}
		@RequestMapping("/admin")
		public String admin()
		{
			return "admin.jsp";
		}
		@RequestMapping("/expert")
		public String expert()
		{
			return "admin.jsp";
		}
		@RequestMapping("/farmer")
		public String farmer()
		{
			return "farmer.jsp";
		}
		@RequestMapping("/viewDataSetImgs")
		public ModelAndView viewDataSetImgs()
		{
			ModelAndView mv=new ModelAndView();
			mv.setViewName("viewDataSetImg.jsp");
			Crops plant=new Crops();
			plant.getPlants();
			List<Crops> lstplant=plant.getLstplants();
			mv.addObject("lst",lstplant);
			return mv;
		}
		
		@RequestMapping("/TrainDataset")
		public ModelAndView TrainDataset()
		{
			ModelAndView mv=new ModelAndView();
			mv.setViewName("TrainDataset.jsp");
			Crops plant=new Crops();
			plant.getPlants();
			List<Crops> lstplant=plant.getLstplants();
			mv.addObject("lst",lstplant);
			return mv;
		}
		@RequestMapping("/RegCropDetails")
		public ModelAndView RegCropDetails()
		{
			ModelAndView mv=new ModelAndView();
			mv.setViewName("RegCropDetails.jsp");
			Crops plant=new Crops();
			plant.getPlants();
			List<Crops> lstplant=plant.getLstplants();
			mv.addObject("lst",lstplant);
			return mv;
		}
		@RequestMapping("PlantDetailsReg")
		public String PlantDetailsReg(CropDetails obj)
		{
			 try
			 {
				 if(obj.registration() )
				 {
					 
					 return "Success.jsp?type=RegPrev";
				 }
				 else
				 { 
					 return "Failure.jsp?type=RegPrev";
				 }
			 }
			 catch (Exception e) {
				// TODO: handle exception
				 System.out.println("err="+e.getMessage());
				 return("Failure.jsp?type=RegUser");
			}
		}
		@RequestMapping("/viewDataSetImg1")
		public ModelAndView viewDataSetImg1(HttpSession ses,HttpServletRequest request)
		{
			
			List<CropDiseaseImg> lst = new ArrayList<CropDiseaseImg>();
			CropDiseaseImg obj=new CropDiseaseImg();
			obj.setPlantName(request.getParameter("plantName").toString().trim());
			obj.setDisease(request.getParameter("disease").toString().trim());
			obj.getPlantDiseaseImg();
			 lst=obj.getLstplants();

			ModelAndView mv = new ModelAndView();
			System.out.println("lst="+lst.size());
			mv.setViewName("datasetImgs.jsp");
			mv.addObject("lst", lst); 
			return mv;
			 
		}
		@RequestMapping("Input_ImagesInsrtPython")
		public ModelAndView Input_ImagesInsrtPython(HttpServletRequest request)
		{
			List<CropDisease> lstdisease=new ArrayList<CropDisease>();
			ModelAndView mv=new ModelAndView();
			try
			 {
				 int imgid=Integer.parseInt(request.getParameter("imgId").trim());
				 String plantName=(request.getParameter("plant").trim());
				JavaFuns jf=new JavaFuns();
				 
				 CropDiseaseImgFarmer obj=new CropDiseaseImgFarmer();
				 Vector v=jf.getValue("select count(*) from imgdataset where plantName='"+plantName.trim()+"'", 1);
				 if(v.elementAt(0).toString().trim().equals("0"))
				 {
					 if(jf.execute("delete from eval where imgid="+imgid))
					 {}
					 mv.setViewName("Failure.jsp?type=DataSetNotFound");
				 }
				 else
				 {
				 double starttm=System.currentTimeMillis();	          
				 lstdisease=obj.getDetectedDisease(imgid,plantName);
				 double endtime=System.currentTimeMillis();
				 double tm=endtime-starttm;
				 if(jf.execute("update eval set classificationTime=sparsetime+"+tm+", exetime=hogtime+"+tm+" where imgid="+imgid))
				 {}
				 mv.setViewName("showDetectedDis.jsp");
				 mv.addObject("lst",lstdisease);
				 }
			 }
			 catch (Exception e) {
				// TODO: handle exception
				 System.out.println("err="+e.getMessage());
				 mv.setViewName("Failure.jsp?type=InputImgInsrt");
	 		}
			return mv;
		}
		@RequestMapping("Input_ImagesInsrtPythonAcc")
		public ModelAndView Input_ImagesInsrtPythonAcc(HttpServletRequest request)
		{
			List<CropDisease> lstdisease=new ArrayList<CropDisease>();
			ModelAndView mv=new ModelAndView();
			try
			 {
				 int imgid=Integer.parseInt(request.getParameter("imgId").trim());
				 String plantName=(request.getParameter("plant").trim());
				 String disease=(request.getParameter("disease").trim());
				JavaFuns jf=new JavaFuns();
				 
				 CropDiseaseImgFarmer obj=new CropDiseaseImgFarmer();
				 Vector v=jf.getValue("select count(*) from imgdataset where plantName='"+plantName.trim()+"'", 1);
				 if(v.elementAt(0).toString().trim().equals("0"))
				 {
					 if(jf.execute("delete from eval where imgid="+imgid))
					 {}
					 
					 mv.setViewName("Failure.jsp?type=DataSetNotFound");
				 }
				 else
				 {
				 double starttm=System.currentTimeMillis();	          
				 lstdisease=obj.getDetectedDisease(imgid,plantName);
				 double endtime=System.currentTimeMillis();
				 double tm=endtime-starttm;
				 if(jf.execute("update eval set classificationTime=sparsetime+"+tm+", exetime=hogtime+"+tm+" where imgid="+imgid))
				 {}
				 Vector vct=jf.getValue("select diseaseName from knn3 where inputImage="+imgid+" and eudist=(select min(eudist) from knn3) limit 1",1);
				 try {
				 if(jf.execute("insert into accuracy values("+imgid+",'"+disease+"','"+vct.elementAt(0).toString().trim()+"')"))
				 {}
				 }
				 catch (Exception e11) {
					// TODO: handle exception
				}
				 {}
				 
				 mv.setViewName("showDetectedDis.jsp");
				 mv.addObject("lst",lstdisease);
				 }
			 }
			 catch (Exception e) {
				// TODO: handle exception
				 System.out.println("err="+e.getMessage());
				 mv.setViewName("Failure.jsp?type=InputImgInsrt");
	 		}
			return mv;
		}
		@RequestMapping("datasetInsrtPython")
		public String datasetInsrtPython()
		{
			 try
			 {
				 
				 return "Success.jsp?type=datasetInsrt";
				  
			 }
			 catch (Exception e) {
				// TODO: handle exception
				 System.out.println("err="+e.getMessage());
				 return("Failure.jsp?type=datasetInsrt");
			}
		}
		@RequestMapping("PlantsReg")
		public String PlantsReg(Crops obj)
		{
			 try
			 {
				 if(obj.registration() )
				 {
					 
					 return "Success.jsp?type=RegCrop";
				 }
				 else
				 { 
					 return "Failure.jsp?type=RegCrop";
				 }
			 }
			 catch (Exception e) {
				// TODO: handle exception
				 System.out.println("err="+e.getMessage());
				 return("Failure.jsp?type=RegUser");
			}
		}
		@RequestMapping("PlantsDiseaseReg")
		public String PlantsDiseaseReg(CropDisease obj)
		{
			 try
			 {
				 if(obj.registration() )
				 {
					 
					 return "Success.jsp?type=RegCropDisease";
				 }
				 else
				 { 
					 return "Failure.jsp?type=RegCropDisease";
				 }
			 }
			 catch (Exception e) {
				// TODO: handle exception
				 System.out.println("err="+e.getMessage());
				 return("Failure.jsp?type=RegUser");
			}
		}
		@RequestMapping("PlantsDiseaseImgReg")
		public String PlantsDiseaseImgReg(CropDiseaseImg obj,HttpServletRequest request,HttpSession ses)
		{
			 try
			 {
				 MultipartFile file=obj.getFile();
			  
			 String filepath=request.getServletContext().getRealPath("/")+"/DataSetImages/";
			  
			 System.out.println("path="+filepath);
			 File f=new File(filepath);
			 f.mkdir();
			 filepath+="/"+ses.getAttribute("userid").toString().trim();
			 f=new File(filepath);
			 f.mkdir();
			  
				 obj.generateImgId();
				 int mx=obj.getImgId();
				 String fileName=mx+"."+ file.getOriginalFilename().split("\\.")[1];
				 file.transferTo(new File(filepath+"/"+fileName));
				 if(obj.registration() )
				 {
					 
					 return "Success.jsp?type=RegCropDisease";
				 }
				 else
				 { 
					 return "Failure.jsp?type=RegCropDisease";
				 }
			 }
			 catch (Exception e) {
				// TODO: handle exception
				 System.out.println("err="+e.getMessage());
				 return("Failure.jsp?type=RegUser");
			}
		}
		@RequestMapping("/login")
		public String login(HttpServletRequest request)
		{
			 Login obj=new Login();
			 try
			 {
				 HttpSession ses=request.getSession(true);
				 
				 if(obj.chkAuthentication(request.getParameter("txtuserid").trim(), request.getParameter("txtpass").trim()))
				 {
					 ses.setAttribute("userid", obj.getUserid());
					 System.out.println("userid="+obj.getUserid());
					 System.out.println("userid="+obj.getuType());
					 System.out.println("userid="+obj.getUserName());
					 ses.setAttribute("utype", obj.getuType());
					 ses.setAttribute("email", obj.getEmail());
					 ses.setAttribute("username", obj.getUserName());
					 return obj.getuType()+".jsp";
				 }
				 else
				 { 
					 return "Failure.jsp?type=Auth";
				 }
			 }
			 catch (Exception e) {
				// TODO: handle exception
				 System.out.println("err="+e.getMessage());
				 return("Failure.jsp?type=Auth");
			}
			 
		}
		@RequestMapping("/logout")
		public String logout(HttpSession session) {
	        session.invalidate();
			return "Logout.jsp";
		}
}
