package com.models;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.services.DBConnector;
public class Crops {
	Connection con;
    CallableStatement csmt;
    ResultSet rs;
    private List<Crops> lstplants;
    private String name,details,userid;
   public Crops() {}
      
       
	public List<Crops> getLstplants() {
	return lstplants;
}


public void setLstplants(List<Crops> lstplants) {
	this.lstplants = lstplants;
}


public String getName() {
	return name;
}


public void setName(String name) {
	this.name = name;
}


public String getDetails() {
	return details;
}


public void setDetails(String details) {
	this.details = details;
}


public String getUserid() {
	return userid;
}


public void setUserid(String userid) {
	this.userid = userid;
}


	public Crops(ResultSet rs)
	{
		try
		{
		name=rs.getString("name").toString().trim();
		details=rs.getString("details").toString().trim();
		userid=rs.getString("userid").toString().trim(); 
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("err="+e.getMessage());
		}
	}
	public void getPlants()
	{
	    try
	    {
	         DBConnector obj=new  DBConnector();
	        con=obj.connect();
	        csmt=con.prepareCall("{call getPlants()}");
	         
	        lstplants=new ArrayList<Crops>();
	         
	         csmt.execute();
	         rs=csmt.getResultSet();
	               
	        while(rs.next())
	        { System.out.println("true");
	        lstplants.add(new Crops(rs));
	              
	        }
	    }
	       
	     
	    catch(Exception ex)
	    {
	        System.out.println("err="+ex.getMessage());
	         
	    }
	}
	 
	public boolean registration()
	    {
	        try
	        {
	        	String bodycond="NA";
	             DBConnector obj=new  DBConnector();
	            con=obj.connect();
	            csmt=con.prepareCall("{call insertPlant(?,?,?)}");
	            csmt.setString(1, userid);
	            csmt.setString(2, name);
	            csmt.setString(3, details);
	              
	             int n=csmt.executeUpdate();
	             
	                        
	            
	            if(n>0)
	            {
	                try{con.close();}catch(Exception ex){}
	                System.out.println("true");
	                return true;
	            }
	            else
	                return false;

	            }
	           
	         
	        catch(Exception ex)
	        {
	            System.out.println("err="+ex.getMessage());
	            return false;
	        }
	    }
	 
}
