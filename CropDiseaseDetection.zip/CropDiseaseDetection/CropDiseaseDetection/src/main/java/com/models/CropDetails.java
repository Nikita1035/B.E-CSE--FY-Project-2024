package com.models;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.services.DBConnector;

 
public class CropDetails {
	Connection con;
    CallableStatement csmt;
    ResultSet rs;
    private List<CropDetails> lstplants;
    private String title,details,userid,plantName,name,weather,refLink,type,soiltype;
   public CropDetails() {}
      
        
	public List<CropDetails> getLstplants() {
	return lstplants;
}


public void setLstplants(List<CropDetails> lstplants) {
	this.lstplants = lstplants;
}


public String getTitle() {
	return title;
}


public void setTitle(String title) {
	this.title = title;
}


public String getDetails() {
	return details;
}


public void setDetails(String details) {
	this.details = details;
}


public String getUserid() {
	return userid;
}


public void setUserid(String userid) {
	this.userid = userid;
}


public String getPlantName() {
	return plantName;
}


public void setPlantName(String plantName) {
	this.plantName = plantName;
}


public String getName() {
	return name;
}


public void setName(String name) {
	this.name = name;
}


public String getWeather() {
	return weather;
}


public void setWeather(String weather) {
	this.weather = weather;
}


public String getRefLink() {
	return refLink;
}


public void setRefLink(String refLink) {
	this.refLink = refLink;
}


public String getType() {
	return type;
}


public void setType(String type) {
	this.type = type;
}


public String getSoiltype() {
	return soiltype;
}


public void setSoiltype(String soiltype) {
	this.soiltype = soiltype;
}


	public CropDetails(ResultSet rs)
	{
		try
		{
		name=rs.getString("diseaseName").toString().trim();
		details=rs.getString("details").toString().trim();
		userid=rs.getString("userid").toString().trim();
		type=rs.getString("typ").toString().trim();
		plantName=rs.getString("plantName").toString().trim();
		weather=rs.getString("weatherTxt").toString().trim();
		soiltype=rs.getString("soilType").toString().trim();
		refLink=rs.getString("refLink").toString().trim();
		title=rs.getString("title").toString().trim();
		refLink=rs.getString("refLink").toString().trim();
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("err="+e.getMessage());
		}
	}
	public void getPlantDetails()
	{
	    try
	    {
	         DBConnector obj=new  DBConnector();
	        con=obj.connect();
	        csmt=con.prepareCall("{call getPlantDetails1(?,?,?)}");
	        csmt.setString(1, plantName);
	        csmt.setString(2, name);
	        csmt.setString(3, soiltype);
	        System.out.println("plantnm="+plantName+" name="+name+" type="+soiltype);
	        lstplants=new ArrayList<CropDetails>();
	         
	         csmt.execute();
	         rs=csmt.getResultSet();
	                     
	        while(rs.next())
	        { System.out.println("true");
	        lstplants.add(new CropDetails(rs));
	              
	        }
	    }
	       
	     
	    catch(Exception ex)
	    {
	        System.out.println("err="+ex.getMessage());
	         
	    }
	}
	 
	public boolean registration()
	    {
	        try
	        { 
	             DBConnector obj=new  DBConnector();
	            con=obj.connect();
	            csmt=con.prepareCall("{call insertExpertSuggestions(?,?,?,?,?,?,?,?,?)}");
	            csmt.setString(1, userid);
	            csmt.setString(2, "NA");
	            csmt.setString(3, title);
	            csmt.setString(4, plantName);
	            csmt.setString(5, name);
	            csmt.setString(6, details);
	            csmt.setString(7, refLink);
	            csmt.setString(8, soiltype);
	            csmt.setString(9, weather);
	             int n=csmt.executeUpdate();
	             
	                        
	            
	            if(n>0)
	            {
	                try{con.close();}catch(Exception ex){}
	                System.out.println("true");
	                return true;
	            }
	            else
	                return false;

	            }
	           
	         
	        catch(Exception ex)
	        {
	            System.out.println("err="+ex.getMessage());
	            return false;
	        }
	    }
	 
}

