package com.models;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.services.DBConnector;
public class CropDiseaseImg {
	Connection con;
    CallableStatement csmt;
    ResultSet rs;
    private List<CropDiseaseImg> lstplants;
    private String name,details,userid,plantName,imgPath,disease;
    private MultipartFile file;
    private int imgId;
   public CropDiseaseImg() {}
      
       
	public String getImgPath() {
	return imgPath;
}


public String getDisease() {
		return disease;
	}


	public void setDisease(String disease) {
		this.disease = disease;
	}


public void setImgPath(String imgPath) {
	this.imgPath = imgPath;
}


	public int getImgId() {
	return imgId;
}


public void setImgId(int imgId) {
	this.imgId = imgId;
}


	public List<CropDiseaseImg> getLstplants() {
	return lstplants;
}

	
	    public MultipartFile getFile() {
			return file;
		}



		public void setFile(MultipartFile file) {
			this.file = file;
		}
public String getPlantName() {
		return plantName;
	}


	public void setPlantName(String plantName) {
		this.plantName = plantName;
	}


public void setLstplants(List<CropDiseaseImg> lstplants) {
	this.lstplants = lstplants;
}


public String getName() {
	return name;
}


public void setName(String name) {
	this.name = name;
}


public String getDetails() {
	return details;
}


public void setDetails(String details) {
	this.details = details;
}


public String getUserid() {
	return userid;
}


public void setUserid(String userid) {
	this.userid = userid;
}


	public CropDiseaseImg(ResultSet rs)
	{
		try
		{
		disease=rs.getString("diseaseName").toString().trim();
		imgPath=rs.getString("imgPath").toString().trim();
		plantName=rs.getString("plantName").toString().trim();
		userid=rs.getString("userid").toString().trim();
		imgId=rs.getInt("imgId");
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("err="+e.getMessage());
		}
	}
	public void getPlantDiseaseImg()
	{
	    try
	    {
	         DBConnector obj=new  DBConnector();
	        con=obj.connect();
	        csmt=con.prepareCall("{call getPlantDiseaseImg(?,?)}");
	         csmt.setString(1, plantName);
	         csmt.setString(2, disease);
	        lstplants=new ArrayList<CropDiseaseImg>();
	         
	         csmt.execute();
	         rs=csmt.getResultSet();
	                     
	        while(rs.next())
	        { System.out.println("true");
	        lstplants.add(new CropDiseaseImg(rs));
	              
	        }
	    }
	       
	     
	    catch(Exception ex)
	    {
	        System.out.println("err="+ex.getMessage());
	         
	    }
	}
	public void generateImgId()
	{
	    try
	    {
	         DBConnector obj=new  DBConnector();
	        con=obj.connect();
	        csmt=con.prepareCall("{call getMaxIdPlantImg()}");
	       
	         csmt.execute();
	         rs=csmt.getResultSet();
	                    
	        boolean auth=false;
	        while(rs.next())
	        { System.out.println("true");
	            auth=true;
	            
	            imgId=rs.getInt("mxid");
	            if(imgId==0 || imgId==1000)
	            	imgId=1001;
	            else
	            	imgId+=1;
	              
	        }
	    }
	       
	     
	    catch(Exception ex)
	    {
	        System.out.println("err="+ex.getMessage());
	         
	    }
	}
	public boolean registration()
	    {
	        try
	        { 
	             DBConnector obj=new  DBConnector();
	            con=obj.connect();
	            csmt=con.prepareCall("{call insertPlantDiseases(?,?,?,?)}");
	            csmt.setString(1, userid);
	            csmt.setString(2, name);
	            csmt.setString(3, details);
	            csmt.setString(4, plantName);
	             int n=csmt.executeUpdate();
	             
	                        
	            
	            if(n>0)
	            {
	                try{con.close();}catch(Exception ex){}
	                System.out.println("true");
	                return true;
	            }
	            else
	                return false;

	            }
	           
	         
	        catch(Exception ex)
	        {
	            System.out.println("err="+ex.getMessage());
	            return false;
	        }
	    }
	 
}
